def convert(amount: float, rate: float) -> float:
    return amount * rate
